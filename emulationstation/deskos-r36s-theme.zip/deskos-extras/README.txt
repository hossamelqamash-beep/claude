DeskOS - optional extras

splash.svg  Hourglass "Loading..." screen for EmulationStation.
            Copy it to  ~/.emulationstation/resources/splash.svg
            (on ArkOS: /home/ark/.emulationstation/resources/splash.svg)
            Delete it to go back to the stock splash.

loading_<colorset>.png / .jpg / .gif
            Full-screen loading images in every colorset, for firmwares
            that support launch images or a custom boot logo.
